/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Jul 30 14:40:42 2009
 */
/* Compiler settings for E:\ChenDongTao\DigNoEnd\VC\COM\AtlUmf\AtlUmf.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_Iumfatl = {0xD05FCBD9,0xAB3B,0x433C,{0x95,0x03,0x9E,0xCC,0xC0,0x3D,0x19,0xB8}};


const IID LIBID_ATLUMFLib = {0x5D1F8FAA,0x782F,0x4983,{0xA1,0x11,0x93,0xF2,0x0E,0xF6,0xD2,0x85}};


const IID DIID__IumfatlEvents = {0x2C4D0C4E,0xFF51,0x4760,{0x8F,0xAB,0xDA,0xF0,0x24,0xD7,0x7A,0x5B}};


const CLSID CLSID_umfatl = {0x8B5A1D0B,0x4142,0x4EE1,{0xB2,0x47,0x56,0xDF,0xD7,0xC1,0xCA,0xCA}};


#ifdef __cplusplus
}
#endif

