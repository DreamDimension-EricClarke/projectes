// umfatl.h : Declaration of the Cumfatl

#ifndef __UMFATL_H_
#define __UMFATL_H_

#include "resource.h"       // main symbols
#include <objsafe.h>  
#include "atlctl.h"//������ȫ�ӿڵ�ͷ�ļ�

/////////////////////////////////////////////////////////////////////////////
// Cumfatl
class ATL_NO_VTABLE Cumfatl : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<Cumfatl, &CLSID_umfatl>,
	public IConnectionPointContainerImpl<Cumfatl>,
	public IDispatchImpl<Iumfatl, &IID_Iumfatl, &LIBID_ATLUMFLib>,
	public IObjectSafetyImpl<Cumfatl,INTERFACESAFE_FOR_UNTRUSTED_CALLER||INTERFACESAFE_FOR_UNTRUSTED_DATA>
{
public:
	Cumfatl()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_UMFATL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(Cumfatl)
	COM_INTERFACE_ENTRY(Iumfatl)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(IObjectSafety)//��ȫ�ӿ�
END_COM_MAP()
 

BEGIN_CONNECTION_POINT_MAP(Cumfatl)
END_CONNECTION_POINT_MAP()

// Iumfatl
public:
	STDMETHOD(findcardHex)(/*[in]*/short hdev,/*[in]*/short mode,/*[out,retval]*/BSTR* strcard);
	STDMETHOD(directWrite)(/*[in]*/short hdev,/*[in]*/short blk,/*[in]*/BSTR wtdata,/*[out,retval]*/short *resul);
	STDMETHOD(directRead)(/*[in]*/short hdev,/*[in]*/short blk,/*[out,retval]*/BSTR *blkdata);
	STDMETHOD(reset)(/*[in]*/short icdev,/*[in]*/short Msec,/*[out,retval]*/short *resul);
	STDMETHOD(fcpuCommandlink)(/*[in]*/short icdev,/*[in]*/short slen,/*[in]*/BSTR sdata,/*[in]*/short tt,/*[in]*/short FG,/*[out,retval]*/BSTR * rdata);
	STDMETHOD(fcpureset)(/*[in]*/short icdev,/*[out]*/short *rlen,/*[out,retval]*/BSTR* rbuf);
	STDMETHOD(halt)(/*[in]*/short hdev, /*[out,retval]*/short *resul);
	STDMETHOD(changkey)(/*[in]*/short hdev,/*[in]*/ short secNr,/*[in]*/ BSTR keya,/*[in]*/ BSTR ctrlword,/*[in]*/short bk,/*[in]*/ BSTR keyb,/*[out,retval]*/ short *resul );
	STDMETHOD(transfer)(/*[in]*/short hdev,/*[in]*/short blk,/*[out,retval]*/short *resul);
	STDMETHOD(decrement)(/*[in]*/short hdev,/*[in]*/ short blk,/*[in]*/ long value,/*[out,retval]*/ short *resul);
	STDMETHOD(increment)(/*[in]*/short hdev,/*[in]*/ short blk, /*[in]*/long value,/*[out,retval]*/short *resul);
	STDMETHOD(initialval)(/*[in]*/short hdev, /*[in]*/short blk, /*[in]*/long value, /*[out,retval]*/short *resul);
	STDMETHOD(readval)(/*[in]*/short hdev,/*[in]*/ short blk, /*[out,retval]*/long *value);
	STDMETHOD(write)(/*[in]*/short hdev,/*[in]*/short blk,/*[in]*/BSTR wtdata,/*[out,retval]*/short *resul);
	STDMETHOD(read)(/*[in]*/short hdev,/*[in]*/short blk,/*[out,retval]*/BSTR *blkdata);
	STDMETHOD(hexToUnchar)(/*[in]*/unsigned char *hex,/*[in]*/short chlen,/*[out,retval]*/unsigned char *a);
	STDMETHOD(loadkey)(/*[in]*/short hdev,/*[in]*/short mode,/*[in]*/ short sNr,/*[in]*/BSTR  key,/*[out,retval]*/short *resul);
	STDMETHOD(authentication)(/*[in]*/ short hdev,/*[in]*/short mode,/*[in]*/short snr,/*[out,retval]*/short *resul);
	STDMETHOD(findcard)(/*[in]*/int hdev,/*[in]*/short mode,/*[out,retval]*/long *ncard);
	STDMETHOD(uncharTounHex)(/*[in]*/unsigned char *a,/*[in]*/short hexlen,/*[out,retval]*/unsigned char *hex);
	STDMETHOD(hexTochar)(/*[in]*/BSTR hexstr,/*[in]*/short chlen,/*[out,retval]*/BSTR *charstr);
	STDMETHOD(select)(/*[in]*/short icdev,/*[in]*/long _Snr,/*[out,retval]*/short *resul);
	STDMETHOD(charToHex)(/*[in]*/BSTR charstr,/*[in]*/short hexlen,/*[out,retval]*/BSTR *hexstr);
	STDMETHOD(anticoll)(/*[in]*/short icdev,/*[in]*/short mode,/*[out,retval]*/long *ncard);
	STDMETHOD(beep)(/*[in]*/short icdev,/*[in]*/short isec,/*[out,retval]*/short *resul);
	STDMETHOD(request)(/*[in]*/short hdev,/*[in]*/short mode,/*[out,retval]*/short *resul);
	STDMETHOD(exit)(/*[in]*/short icdev,/*[out,retval]*/short *resul);
	STDMETHOD(initialcom)(/*[in]*/ int port,/*[in]*/long band,/*[out,retval]*/int *hdev);
};

#endif //__UMFATL_H_
