1. Directory
   1.1. File AtlUmf.dll(under com) is a control be used is web page, should be register before called.
   1.2. There are html and dotNet two directory under example,ATlumftest.htm under html is a simple HTML page to use COM control,
        and there is a simple project create under VS2005 with VB.net.
   1.3. Reg.bat and unreg.bat, is used for register/unregister this COM control.

2. The function of COM control
   2.1. The reader type to support  ��S8 serial
   2.2. The port type to support: USB, Serial port
   2.3. The card type to support: M1(S50),S70,Contactless-CPU

3. The process to test example
   3.1. Copy the umd.dll under :\windows\system32.
   3.2. Run reg.bat under this directory to register AtlUmf.dll.
   3.3. Open the HTML page under example to test.
   3.4. Open IC_FW with VS2005 or higher version of VS to test.

4. Note
   4.1. When use this COM control with IIS server,cliect need add the IP of server machine to trusted site.