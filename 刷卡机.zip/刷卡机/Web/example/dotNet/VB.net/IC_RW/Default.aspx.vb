﻿
Partial Class _Default
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Page.RegisterStartupScript("Connect", "<script   language='JavaScript'>Connect();</script>")
    End Sub

    Protected Sub ButtInit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButtInit.Click
        Me.DDLDriveSchool.Text = ""
        Me.DDLPeriodTime.Text = ""
        Me.TextSerialNo.Text = ""
        Me.TextName.Text = ""
        Me.TextIDcardN.Text = ""
        Me.DDLLicenseType.Text = ""
        Me.TextPersonalTelephone.Text = ""
        Me.TextXslc.Text = ""
        Me.TextPjcs.Text = ""
        Me.TextZgcs.Text = ""
        Me.TextLlxs.Text = ""
        Me.TextMnxs.Text = ""
        Me.TextScxs.Text = ""
    End Sub

    Protected Sub ButtW_IC_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButtW_IC.Click

        Page.RegisterStartupScript("Write", "<script   language='JavaScript'>Write();</script>")


    End Sub

    Protected Sub ButtR_IC0_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButtR_IC0.Click
        Page.RegisterStartupScript("Read", "<script   language='JavaScript'>Read();</script>")

    End Sub
End Class
