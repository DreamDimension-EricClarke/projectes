1.Directory classpackge contain: JAVA JAR file,umf.dll, javacall.java(declaration).
2.Directory example contain a example program which use JAVA library.
3.Note that jumf50.jar should be cope to needed library path of JAVA.
4.umf.dll should be cope to the directory of exe or under /windows/system32.