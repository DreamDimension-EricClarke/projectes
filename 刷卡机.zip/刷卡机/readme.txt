S8 Smart Card Reader v1.4.8.11
==========================
Copyright (c) 2005-2012 Fongwah Inc.

What is S8 Smart card reader?
This set of software for S8-X smart card reader contains SDK (Software Development Kits), routines, Dynamic Link Libraries, controls and other codes or material file. This set of software is distributed together with products.

Statement
------------
This set if software for S8 smartcard reader v1.4.8.11 is for free. If you have any problems when use it, please refer to the part ��Difficulty to use�� in the Help Manual, or make a call to Fongwah Technology. Our Company will take no responsibility for any loss caused by operation with other devices not relevant with this software.  

Distribution
---------------
You can use and distribute this software in case you make not any changes to the files. Other cases must be under the writer��s permission.

System requirement
------------------------
* Windows 2000/XP/2003/Vista or more advanced versions
*IE 5 or more advanced versions (optional)
*Memory: 256 MB 
* Hard disk: more than 12MB  

Installation
--------------
If you download a self-extracting installation file (SETUP.exe), just run the executable file. If you download a Zip archive (S8.zip), you need to first unzip it to a temporary directory, and then run SETUP.EXE.

Uninstallation
-----------------
Find ��S8 Smart card Reader�� via ��Start - Programs��, and click ��Uninstall S8 Smart card Reader��. You can also open the Control Panel, and run ��Add/Remove Program��, and then double-click the ��S8 Smart card Reader v1.4.8.11��.

Feedback
------------
Please send the feedback, advice and any kind of comments to the following email:
market@fongwah.com.