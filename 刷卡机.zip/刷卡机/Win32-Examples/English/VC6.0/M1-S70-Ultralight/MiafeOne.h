// MiafeOne.h : main header file for the MIAFEONE application
//

#if !defined(AFX_MIAFEONE_H__6631BCE6_7FEE_4A16_B17C_99F2EFD64737__INCLUDED_)
#define AFX_MIAFEONE_H__6631BCE6_7FEE_4A16_B17C_99F2EFD64737__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#define   M1           1
#define   S70          2
#define   Ultralight   3
/////////////////////////////////////////////////////////////////////////////
// CMiafeOneApp:
// See MiafeOne.cpp for the implementation of this class
//

class CMiafeOneApp : public CWinApp
{
public:
	CMiafeOneApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMiafeOneApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMiafeOneApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MIAFEONE_H__6631BCE6_7FEE_4A16_B17C_99F2EFD64737__INCLUDED_)
