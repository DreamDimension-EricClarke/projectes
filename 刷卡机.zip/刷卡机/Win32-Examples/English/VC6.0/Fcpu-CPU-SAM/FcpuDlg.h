// FcpuDlg.h : header file
//

#if !defined(AFX_FCPUDLG_H__6F0BAE09_D9EE_4AC5_BC8D_D8A205752221__INCLUDED_)
#define AFX_FCPUDLG_H__6F0BAE09_D9EE_4AC5_BC8D_D8A205752221__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define  FCPU      2 //�ǽ�CPU
#define  CPU       0x0c  //�Ӵ�ʽCPU
#define  SAM1      0x0d	//SAM1
#define  SAM2      0x0e//SAM2
#define  SAM3      0x0f//SAM3

/////////////////////////////////////////////////////////////////////////////
// CFcpuDlg dialog

class CFcpuDlg : public CDialog
{
// Construction
public:
	int cardtype;
	CString pstrMsg;
	int icdev;
	CFcpuDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CFcpuDlg)
	enum { IDD = IDD_FCPU_DIALOG };
	CEdit	m_edtCmd;
	CEdit	m_editMsg;
	CString	m_strMsg;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFcpuDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFcpuDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnTest();
	afx_msg void OnBtnClear();
	afx_msg void OnBtnReset();
	afx_msg void OnBtnSendcmd();
	afx_msg void OnMenuOpen();
	afx_msg void OnMenuCpu();
	afx_msg void OnMenuFcpu();
	afx_msg void OnMenuClose();
	afx_msg void OnMenuSam1();
	afx_msg void OnMenuSam2();
	afx_msg void OnMenuSam3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void ShowMsgchar(unsigned char * showbuf);
	void ShowMsgString(CString str);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FCPUDLG_H__6F0BAE09_D9EE_4AC5_BC8D_D8A205752221__INCLUDED_)
