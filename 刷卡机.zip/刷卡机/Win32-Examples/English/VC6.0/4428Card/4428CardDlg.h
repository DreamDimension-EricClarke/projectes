// 4428CardDlg.h : header file
//

#if !defined(AFX_4428CARDDLG_H__B679891A_DA69_4FB3_B879_B6001CA10769__INCLUDED_)
#define AFX_4428CARDDLG_H__B679891A_DA69_4FB3_B879_B6001CA10769__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMy4428CardDlg dialog

class CMy4428CardDlg : public CDialog
{
// Construction
public:
	CMy4428CardDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMy4428CardDlg)
	enum { IDD = IDD_MY4428CARD_DIALOG };
	CListBox	m_list;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy4428CardDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMy4428CardDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnRead();
	afx_msg void OnBtnInitcom();
	afx_msg void OnBtnAuthen();
	afx_msg void OnBtnWrite();
	afx_msg void OnBtnReadprot();
	afx_msg void OnBtnWriteprot();
	afx_msg void OnBtnChangekey();
	afx_msg void OnBtnCntrerr();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void showMsg(char *data);
	BOOL isAuthened;
	int icdev;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_4428CARDDLG_H__B679891A_DA69_4FB3_B879_B6001CA10769__INCLUDED_)
