// 4442Card.h : main header file for the 4442CARD application
//

#if !defined(AFX_4442CARD_H__59DF9090_4BC1_4CC9_AE6B_7D20D7321A58__INCLUDED_)
#define AFX_4442CARD_H__59DF9090_4BC1_4CC9_AE6B_7D20D7321A58__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMy4442CardApp:
// See 4442Card.cpp for the implementation of this class
//

class CMy4442CardApp : public CWinApp
{
public:
	CMy4442CardApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy4442CardApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMy4442CardApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_4442CARD_H__59DF9090_4BC1_4CC9_AE6B_7D20D7321A58__INCLUDED_)
