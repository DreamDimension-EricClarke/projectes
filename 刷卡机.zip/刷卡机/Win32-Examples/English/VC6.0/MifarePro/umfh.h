//#include "stdafx.h"


#include <windows.h>


#define DLLSPEC extern "C" _declspec(dllexport)

//===============================================
/*----------M1 Commond Functions--------*/
//===============================================
//1
DLLSPEC int _stdcall fw_init(int port,long baud); 
//2
DLLSPEC int _stdcall fw_exit(int icdev);
//3
DLLSPEC int _stdcall fw_card(int icdev,unsigned char _Mode,unsigned long *_Snr);
//4
DLLSPEC int _stdcall fw_request(int icdev,unsigned char _Mode,unsigned int *TagType);
//5
DLLSPEC int _stdcall fw_anticoll(int icdev,unsigned char _Bcnt,unsigned long *_Snr);
//6
DLLSPEC int _stdcall fw_select(int icdev,unsigned long _Snr,unsigned char *_Size);
//7
DLLSPEC int _stdcall fw_load_key(int icdev,unsigned char _Mode,
				unsigned char _SecNr,unsigned char *_NKey);
//8
DLLSPEC int _stdcall fw_authentication(int icdev,unsigned char _Mode,
									   unsigned char _SecNr);
//9
DLLSPEC int _stdcall fw_read(int icdev,unsigned char _Adr,unsigned char *_Data);
//9.1
DLLSPEC __int16 __stdcall fw_read_hex(int icdev,unsigned char _Adr,unsigned char *_Data);
//10
DLLSPEC int _stdcall fw_write(int icdev,unsigned char _Adr,unsigned char *_Data);
//10.1
DLLSPEC __int16 __stdcall fw_write_hex(int icdev,unsigned char _Adr,unsigned char *_Data);
//11
DLLSPEC int _stdcall fw_halt(int icdev);
//12
DLLSPEC int _stdcall fw_des(unsigned char *key,unsigned char *sour,
				   unsigned char *dest,__int16 m);
//13
DLLSPEC int _stdcall fw_changeb3(int icdev,unsigned char _SecNr,
				unsigned char *_KeyA,unsigned char *_CtrlW,unsigned char _Bk,
				unsigned char *_KeyB);
//15
DLLSPEC int _stdcall fw_initval(int icdev,unsigned char _Adr,unsigned long _Value);
//16
DLLSPEC int _stdcall fw_increment(int icdev,unsigned char _Adr,unsigned long _Value);
//17
DLLSPEC int _stdcall fw_readval(int icdev,unsigned char _Adr,unsigned long *_Value);
//18
DLLSPEC int _stdcall fw_decrement(int icdev,unsigned char _Adr,unsigned long _Value);
//19
DLLSPEC int _stdcall fw_HL_authentication(int icdev,unsigned char reqmode,
										  unsigned long snr,unsigned char authmode,
										  unsigned char secnr);
//20
DLLSPEC int _stdcall fw_HL_read(int icdev,unsigned char _Mode,unsigned char _Adr,
			   unsigned long _Snr,unsigned char *_Data, unsigned long *_NSnr);
//21
DLLSPEC int _stdcall fw_HL_write(int icdev,unsigned char _Mode,unsigned char _Adr,
				unsigned long *_Snr,unsigned char *_Data);
//22
DLLSPEC int _stdcall fw_restore(int icdev,unsigned char _Adr);
//23
DLLSPEC int _stdcall fw_transfer(int icdev,unsigned char _Adr);
//24
DLLSPEC int _stdcall fw_authentication_2(int icdev,unsigned char _Mode,unsigned char KeyNr,
						unsigned char Adr);
//25
DLLSPEC int _stdcall fw_authentication_pass(int icdev, unsigned char _Mode, 
											unsigned char Addr,
						   unsigned char *passbuff);
//26
DLLSPEC int _stdcall fw_card_double(int icdev,unsigned char _Mode,unsigned char *_Snr);

//30
DLLSPEC __int16 __stdcall fw_config_card(HANDLE icdev,unsigned char flags);

//===============================================
/*----------M1 device Functions--------*/
//===============================================
//1
DLLSPEC int _stdcall fw_beep(int icdev,unsigned int _Msec);
//2
DLLSPEC int _stdcall fw_disp_mode(int icdev,unsigned char mode);
//2.1
DLLSPEC int _stdcall fw_ctl_mode(int icdev,unsigned char mode);
//3
DLLSPEC int _stdcall fw_lcd_dispstr(int icdev,char *digit);
//4
DLLSPEC int _stdcall fw_gettime(int icdev,unsigned char *time);
//5
DLLSPEC int _stdcall fw_getver(int icdev,unsigned char *buff);
//6
DLLSPEC int _stdcall fw_high_disp(int icdev,unsigned char offset,
								  unsigned char disp_len,unsigned char *disp_str);
//7
DLLSPEC int _stdcall fw_lcd_setbright(int icdev,unsigned char bright);
//8
DLLSPEC int _stdcall fw_settime(int icdev,unsigned char *time);
//9
DLLSPEC int _stdcall fw_srd_eeprom(int icdev,int offset,int length,
								   unsigned char *rec_buffer);
//10
DLLSPEC int _stdcall fw_swr_eeprom(int icdev,int offset,int length,
								   unsigned char* buffer);
//11
DLLSPEC __int16 _stdcall a_hex(unsigned char *a,unsigned char *hex,__int16 len);
//12
DLLSPEC void _stdcall hex_a(unsigned char *hex,unsigned char *a,__int16 len);
//13
DLLSPEC __int16 __stdcall fw_reset(HANDLE icdev,unsigned __int16 _Msec);

//clear Mifare Pro LCD 
DLLSPEC int _stdcall fw_lcd_dispclear(int icdev);
//14 LED 8
DLLSPEC int _stdcall fw_LED_disp8(int icdev,unsigned char strlen,
								  unsigned char* dispstr);


//===============================================
//         4442 Commond Functions
//===============================================
//1
DLLSPEC int _stdcall fw_read_4442(int icdev,unsigned char _Adr,unsigned char *_Data,
								  int length);
//2
DLLSPEC int _stdcall fw_write_4442(int icdev,unsigned char _Adr,unsigned char *_Data,
								   int length);
//3
DLLSPEC int _stdcall fw_getProtectData_4442(int icdev,unsigned char _Adr,
											unsigned char *_Data,int length);
//4
DLLSPEC int _stdcall fw_setProtectData_4442(int icdev,unsigned char _Adr,
											unsigned char *_Data,int length);
//5
DLLSPEC int _stdcall fw_authentikey_4442(int icdev,unsigned char _Adr,int rlen,
										 unsigned char *key);
//6
DLLSPEC int _stdcall fw_changkey_4442(int icdev,unsigned char _Adr,int rlen,
									  unsigned char *key);
//7
DLLSPEC int _stdcall fw_cntReadError_4442(int icdev,unsigned char *cntReadError);


//===============================================
//         4428 Commond Functions
//===============================================
//1
DLLSPEC int _stdcall fw_read_4428(int icdev,unsigned int _Adr,unsigned char *_Data,
								  int length);
//2
DLLSPEC int _stdcall fw_write_4428(int icdev,unsigned int _Adr,unsigned char *_Data,
								   int length);
//3
DLLSPEC int _stdcall fw_getProtectData_4428(int icdev,unsigned int _Adr,
											unsigned char *_Data,int length);
//4
DLLSPEC int _stdcall fw_setProtectData_4428(int icdev,unsigned int _Adr,
											unsigned char *_Data,int length);
//5
DLLSPEC int _stdcall fw_authentikey_4428(int icdev,unsigned char *key);
//6
DLLSPEC int _stdcall fw_changkey_4428(int icdev,unsigned char *key);
//7
DLLSPEC int _stdcall fw_cntReadError_4428(int icdev,unsigned char *cntReadError);


//===============================================
//           cup(SAM)  Functions
//===============================================
//1
DLLSPEC __int16 __stdcall fw_cpureset(HANDLE ICDev,unsigned char *rlen, unsigned char *rbuff);
//2
DLLSPEC __int16 __stdcall fw_setcpu(HANDLE ICDev,unsigned char SAMID);
//3
DLLSPEC __int16 __stdcall fw_cpuapdu(HANDLE ICDev,unsigned char slen,unsigned char * sbuff,
						   unsigned char *rlen,unsigned char * rbuff);
//4
DLLSPEC __int16  __stdcall fw_cpuapdusource(HANDLE ICDev,unsigned char slen,
								 unsigned char * sbuff,unsigned char *rlen,
								 unsigned char * rbuff);
//5
DLLSPEC __int16 __stdcall fw_setcpupara(HANDLE ICDev,unsigned char cputype,
							  unsigned char cpupro,unsigned char cpuetu);



//================================================
//S70 Functions
//S70 operation command most the same as M1
//================================================
//1
DLLSPEC int _stdcall fw_read_S70(int icdev,unsigned char _Adr,unsigned char *_Data);
//2
DLLSPEC int _stdcall fw_write_S70(int icdev,unsigned char _Adr,unsigned char *_Data);




//================================================
//     UltraLight card  Functions
//================================================
//1 request
DLLSPEC int _stdcall fw_request_ultralt(int icdev,unsigned char _Mode);
//2 anticall
DLLSPEC int _stdcall fw_anticall_ultralt(int icdev,unsigned long *_Snr);
//3 select
DLLSPEC int _stdcall fw_select_ultralt(int icdev,unsigned long _Snr);
//4 reqa
DLLSPEC int _stdcall fw_reqa_ultralt(int icdev,unsigned char _Bcnt,unsigned long _Snr);
//5 wake up
DLLSPEC int _stdcall fw_wakeup_ultralt(int icdev,unsigned char _Snr);
//4 read
DLLSPEC int _stdcall fw_read_ultralt(int icdev,unsigned char iPage,unsigned char *redata);
//5 write
DLLSPEC int _stdcall fw_write_ultralt(int icdev,unsigned char iPage,unsigned char *sdata);
//6 Halt
DLLSPEC int _stdcall fw_halt_ultralt(int icdev);



//===============================================
//       MifarePro card  Functions
//===============================================

//1
DLLSPEC __int16 _stdcall fw_reset_mifarepro(int icdev,unsigned char *rlen, unsigned char *rbuff);
//2
DLLSPEC __int16 _stdcall fw_setcpu_mifarepro(int icdev,unsigned char SAMID);
//3
DLLSPEC __int16 _stdcall fw_apdu_mifarepro(int icdev,unsigned char slen,unsigned char * sbuff,
						   unsigned char *rlen,unsigned char * rbuff);

//4
DLLSPEC __int16 _stdcall fw_setpara_mifarepro(int icdev,unsigned char cputype,unsigned char cpupro,
							  unsigned char cpuetu);

//===============================================
//       Icode2 card  Functions
//===============================================

DLLSPEC __int16 __stdcall fw_inventory(HANDLE icdev,unsigned char flags,
							   unsigned char AFI, 
							   unsigned char masklen, 
							   unsigned char *rlen,unsigned char *rbuffer);
//__int16 __stdcall fw_inventory_hex(HANDLE icdev,unsigned char flags,
//							   unsigned char AFI, 
//							   unsigned char masklen, 
//							   unsigned char *rlen,unsigned char *rbuffer);
DLLSPEC __int16 __stdcall fw_stay_quiet(HANDLE icdev,unsigned char flags,unsigned char *UID);
//__int16 __stdcall fw_stay_quiet_hex(HANDLE icdev,unsigned char flags,unsigned char *UID);
DLLSPEC __int16 __stdcall fw_select_uid(HANDLE icdev,unsigned char flags,unsigned char *UID);
//__int16 __stdcall fw_select_uid_hex(HANDLE icdev,unsigned char flags,unsigned char *UID);
DLLSPEC __int16 __stdcall fw_reset_to_ready(HANDLE icdev,unsigned char flags,unsigned char *UID);
//__int16 __stdcall fw_reset_to_ready_hex(HANDLE icdev,unsigned char flags,unsigned char *UID);
DLLSPEC __int16 __stdcall fw_readblock(HANDLE icdev,unsigned char flags,
							   unsigned char startblock,unsigned char blocknum, 
							   unsigned char *UID, 
							   unsigned char *rlen,unsigned char *rbuffer);
//__int16 __stdcall fw_readblock_hex(HANDLE icdev,unsigned char flags,
//							   unsigned char startblock,unsigned char blocknum, 
//							   unsigned char *UID, 
//							   unsigned char *rlen,unsigned char *rbuffer);
DLLSPEC __int16 __stdcall fw_writeblock(HANDLE icdev,unsigned char flags,
								unsigned char startblock,unsigned char blocknum, 
								unsigned char *UID, 
								unsigned char wlen,unsigned char *rbuffer);
//__int16 __stdcall fw_writeblock_hex(HANDLE icdev,unsigned char flags,
//								unsigned char startblock,unsigned char blocknum, 
//								unsigned char *UID, 
//								unsigned char wlen,unsigned char *rbuffer);
DLLSPEC __int16 __stdcall fw_lock_block(HANDLE icdev,unsigned char flags,unsigned char block,
								unsigned char *UID);
//__int16 __stdcall fw_lock_block_hex(HANDLE icdev,unsigned char flags,unsigned char block,
//								unsigned char *UID);
DLLSPEC __int16 __stdcall fw_write_afi(HANDLE icdev,unsigned char flags,unsigned char AFI,
							   unsigned char *UID);
//__int16 __stdcall fw_write_afi_hex(HANDLE icdev,unsigned char flags,unsigned char AFI,
//							   unsigned char *UID);
DLLSPEC __int16 __stdcall fw_lock_afi(HANDLE icdev,unsigned char flags,unsigned char AFI,
							  unsigned char *UID);
//__int16 __stdcall fw_lock_afi_hex(HANDLE icdev,unsigned char flags,unsigned char AFI,
//							  unsigned char *UID);
DLLSPEC __int16 __stdcall fw_write_dsfid(HANDLE icdev,unsigned char flags,unsigned char DSFID,
								 unsigned char *UID);
//__int16 __stdcall fw_write_dsfid_hex(HANDLE icdev,unsigned char flags,unsigned char DSFID,
//								 unsigned char *UID);
DLLSPEC __int16 __stdcall fw_lock_dsfid(HANDLE icdev,unsigned char flags,unsigned char DSFID,
								unsigned char *UID);
//__int16 __stdcall fw_lock_dsfid_hex(HANDLE icdev,unsigned char flags,unsigned char DSFID,
//								unsigned char *UID);
DLLSPEC __int16 __stdcall fw_get_systeminfo(HANDLE icdev,unsigned char flags,
									unsigned char *UID, 
									unsigned char *rlen,unsigned char *rbuffer);
//__int16 __stdcall fw_get_systeminfo_hex(HANDLE icdev,unsigned char flags,
//									unsigned char *UID, 
//									unsigned char *rlen,unsigned char *rbuffer);
DLLSPEC __int16 __stdcall fw_get_securityinfo(HANDLE icdev,unsigned char flags,
									  unsigned char startblock,unsigned char blocknum, 
									  unsigned char *UID, 
									  unsigned char *rlen,unsigned char *rbuffer);
//__int16 __stdcall fw_get_securityinfo_hex(HANDLE icdev,unsigned char flags,
//									  unsigned char startblock,unsigned char blocknum, 
//									  unsigned char *UID, 
//									  unsigned char *rlen,unsigned char *rbuffer);


//===============================================
//       typeB at88rf020  card  Functions
//===============================================

DLLSPEC __int16 __stdcall fw_request_b(HANDLE icdev,unsigned char _Mode,unsigned char AFI, 
		                       unsigned char N,unsigned char *ATQB);
DLLSPEC __int16 __stdcall fw_attrib(HANDLE icdev,unsigned char *PUPI, unsigned char CID);
DLLSPEC __int16 __stdcall fw_check_at(HANDLE icdev,unsigned char cid,unsigned char *key);
DLLSPEC __int16 __stdcall fw_read_at(HANDLE icdev,unsigned char Adr,unsigned char*key,
							 unsigned char* rbuffer);
DLLSPEC __int16 __stdcall fw_write_at(HANDLE icdev,unsigned char Adr,unsigned char* sbuffer);
DLLSPEC __int16 __stdcall fw_lock_at(HANDLE icdev,unsigned char Adr,unsigned char*sbuffer);

//ȡ��ѡ��
DLLSPEC __int16 __stdcall fw_halt_at(HANDLE icdev,unsigned char cid,unsigned char *key);

DLLSPEC __int16 __stdcall fw_count_at(HANDLE icdev,unsigned char cid,unsigned char* key);

//===============================================
//       ISO14443-4 ��
//===============================================

//1
DLLSPEC __int16 __stdcall
fw_pro_reset
(
 int ICDev,//�˿ڱ�ʶ��
 unsigned char *rlen,//���ظ�λ��Ϣ�ĳ���
 unsigned char * rbuff//��ŷ��صĸ�λ��Ϣ
 );

//2
DLLSPEC __int16 __stdcall
fw_pro_commandlink
(
 int ICDev,//�˿ڱ�ʶ��
 unsigned char slen,//���͵���Ϣ����
 unsigned char * sbuff,//���Ҫ���͵���Ϣ
 unsigned char *rlen,//������Ϣ�ĳ���
 unsigned char * rbuff,//��ŷ��ص���Ϣ
 unsigned char tt,//�ӳ�ʱ�䣬��λΪ��10ms
 unsigned char FG//�ָ�ȡ������ֵС��64
 );

//===============================================
//       ISO14443 desfire  card  Functions
//===============================================

DLLSPEC int _stdcall fw_anticoll2(int icdev,unsigned char _Bcnt,unsigned long *_Snr);
DLLSPEC int _stdcall fw_select2(int icdev,unsigned long _Snr);
DLLSPEC int __stdcall fw_reset_desfire(int icdev,unsigned char *rlen,unsigned char*rdata);
DLLSPEC int __stdcall fw_apdu_desfire(int icdev,unsigned char slen,unsigned char*sdata,
									  unsigned char *rlen,unsigned char*rdata);
//Applications 
DLLSPEC int __stdcall fw_authen_desfire(int icdev,unsigned char keyNo, char* 
										key,unsigned char* sessionKey);
DLLSPEC int __stdcall fw_getver_desfire(int icdev,unsigned char* rlen,unsigned char* version);
DLLSPEC int __stdcall fw_getAIDs_desfire(int icdev,unsigned char* rlen,unsigned char* AIDS);
DLLSPEC int __stdcall fw_selectApp_desfire(int icdev,unsigned char* AID);
DLLSPEC int __stdcall fw_getKeySetting_desfire(int icdev,unsigned char* rlen,unsigned char*setbuf);
DLLSPEC int __stdcall fw_getKeyver_desfire(int icdev,unsigned char keyNo,unsigned char* keyVer);
DLLSPEC int __stdcall fw_createApp_desfire(int icdev,unsigned char*AID,unsigned char KeySetting,
										   unsigned char NumOfKey);
DLLSPEC int __stdcall fw_delAID_desfire(int icdev,unsigned char* AID);
DLLSPEC int __stdcall fw_changeKeySetting_desfire(int icdev,unsigned char newSet,char* sessionKey);
DLLSPEC int __stdcall fw_changeKey_desfire(int icdev,unsigned char* sessionKey,unsigned char* curKey,
										   unsigned char keyNo,unsigned char* newkey);
DLLSPEC int __stdcall fw_getFileIDs_desfire(int icdev,unsigned char* rlen,unsigned char* fileIDs);
DLLSPEC int __stdcall fw_getFileProper(int icdev,unsigned char fileNo,unsigned char* rlen,
									   unsigned char * fileProper);
DLLSPEC int __stdcall fw_changeFileSetting(int icdev,unsigned char fileNo,unsigned char comSet,
										   unsigned char* accessRight,char* sessionKey);
DLLSPEC int __stdcall fw_createDataFile_desfire(int icdev,unsigned char fileNo,unsigned char ComSet,
												unsigned char* AccessRight,unsigned char* FileSize);
DLLSPEC int __stdcall fw_createValueFile_desfire(int icdev,unsigned char fileNo,unsigned char ComSet,
												 unsigned char* AccessRight,unsigned char*
												 lowerLimit,unsigned char* upperLimit,unsigned
												 char* value,unsigned char creditEnabled);
DLLSPEC int __stdcall fw_createCsyRecord_desfire(int icdev,unsigned char fileNo,unsigned char comSet,
												 unsigned char* AccessRight,unsigned char* RecordSize,
												 unsigned char* MaxNum);
DLLSPEC int __stdcall fw_delFile_desfire(int icdev,unsigned char fileNo);
DLLSPEC int __stdcall fw_write_desfire(int icdev,unsigned char fileNo,unsigned int offset,unsigned int length,
									   unsigned char* data,char*sessionKey);
DLLSPEC int __stdcall fw_read_desfire(int icdev,unsigned char fileNo,unsigned int offset,unsigned int length,
									  unsigned char* revData,char*sessionKey);
DLLSPEC int __stdcall fw_getvalue_desfire(int icdev,unsigned char fileNo,
										  unsigned int* value,char* sessionKey);
DLLSPEC int __stdcall fw_credit_desfire(int icdev,unsigned char fileNo,
										unsigned int value,char*sessionKey);
DLLSPEC int __stdcall fw_debit_desfire(int icdev,unsigned char fileNo,
									   unsigned int value,char*sessionKey);
DLLSPEC int __stdcall fw_writeRecord_desfire(int icdev,unsigned char fileNo,
											 unsigned int offset,unsigned int length,
											 unsigned char* data,char*sessionKey);
DLLSPEC int __stdcall fw_readRecord_desfire(int icdev,unsigned char fileNo,
											unsigned int offset,unsigned int length,
											unsigned char* revData,unsigned int* SgRecordlen,
											unsigned int*rlen,char*sessionKey);
DLLSPEC int __stdcall fw_clearRecord_desfire(int icdev,unsigned char fileNo);
DLLSPEC int __stdcall fw_commitTransfer_desfire(int icdev);
DLLSPEC int __stdcall fw_abortTransfer_desfire(int icdev);
DLLSPEC int __stdcall fw_formatPICC_desfire(int icdev);

//===============================================
//         24C Commond Functions
//===============================================
DLLSPEC int __stdcall fw_read_24c64(int icdev,unsigned int offset,unsigned int length,
									unsigned char* rdata);
DLLSPEC int __stdcall fw_write_24c64(int icdev,unsigned int offset,unsigned int length,
									 unsigned char* wdata);