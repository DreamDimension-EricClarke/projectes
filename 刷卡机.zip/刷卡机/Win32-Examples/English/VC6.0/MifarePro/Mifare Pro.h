// Mifare Pro.h : main header file for the MIFARE PRO application
//

#if !defined(AFX_MIFAREPRO_H__D041F144_1590_4CBA_945C_77D41736AAFC__INCLUDED_)
#define AFX_MIFAREPRO_H__D041F144_1590_4CBA_945C_77D41736AAFC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMifareProApp:
// See Mifare Pro.cpp for the implementation of this class
//

class CMifareProApp : public CWinApp
{
public:
	CMifareProApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMifareProApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMifareProApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MIFAREPRO_H__D041F144_1590_4CBA_945C_77D41736AAFC__INCLUDED_)
