﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace WindowsApplication1
{
    public partial class Form1 : Form
    {
        [DllImport("umf.DLL", EntryPoint = "fw_init")]
        public static extern Int32 fw_init(Int16 port, Int32 baud);
        [DllImport("umf.DLL", EntryPoint = "fw_exit")]
        public static extern Int32 fw_exit(Int32 icdev);
        [DllImport("umf.Dll", EntryPoint = "fw_request")]
        public static extern Int32 fw_request(Int32 icdev, Byte _Mode, ref UInt32 TagType);
        [DllImport("umf.DLL", EntryPoint = "fw_anticoll")]
        public static extern Int32 fw_anticoll(Int32 icdev, Byte _Bcnt, ref ulong _Snr);
        [DllImport("umf.DLL", EntryPoint = "fw_select")]
        public static extern Int32 fw_select(Int32 icdev, UInt32 _Snr, ref Byte _Size);
        [DllImport("umf.DLL",EntryPoint="fw_card")]
        public static extern Int32 fw_card(Int32 icdev,Byte _Mode,ref ulong _Snr);
        [DllImport("umf.DLL",EntryPoint="fw_load_key")]
        public static extern Int32 fw_load_key(Int32 icdev,Byte _Mode,Byte _SecNr,ref Byte _NKey);
        [DllImport("umf.DLL",EntryPoint="fw_authentication")]
        public static extern Int32  fw_authentication(Int32 icdev,Byte _Mode,Byte _SecNr);
        [DllImport("umf.DLL",EntryPoint="fw_read")]
        public static extern  Int32  fw_read(Int32 icdev,Byte _Adr,ref Byte _Data);

        [DllImport("umf.dll",EntryPoint="fw_read_hex")]
        public static extern Int16 fw_read_hex(Int32 icdev, Byte _Adr, StringBuilder _Data);

        [DllImport("umf.DLL", EntryPoint = "fw_write")]
        public static extern  Int32  fw_write(Int32 icdev,Byte _Adr,ref Byte _Data);

        [DllImport("umf.dll", EntryPoint = "fw_write_hex")]
        public static extern Int16 fw_write_hex(Int32 icdev, Byte _Adr, string _Data);

        [DllImport("umf.DLL", EntryPoint = "fw_halt")]
        public static extern  Int32  fw_halt(Int32 icdev);
        [DllImport("umf.DLL", EntryPoint = "fw_changeb3")]
        public static extern Int32  fw_changeb3(Int32 icdev,Byte _SecNr,ref Byte _KeyA,ref Byte _CtrlW,Byte _Bk,
				ref Byte _KeyB);
        [DllImport("umf.DLL", EntryPoint = "fw_initval")]
        public static extern Int32 fw_initval(Int32 icdev,Byte _Adr,UInt32 _Value);
        [DllImport("umf.DLL", EntryPoint = "fw_increment")]
        public static extern Int32 fw_increment(Int32 icdev,Byte _Adr,UInt32 _Value);
        [DllImport("umf.DLL", EntryPoint = "fw_readval")]
        public  static extern Int32 fw_readval(Int32 icdev,Byte _Adr,ref UInt32 _Value);
        [DllImport("umf.DLL", EntryPoint = "fw_decrement")]
        public static extern Int32  fw_decrement(Int32 icdev,Byte _Adr,UInt32 _Value);
        [DllImport("umf.DLL", EntryPoint = "fw_restore")]
        public static extern Int32  fw_restore(Int32  icdev,Byte _Adr);
        [DllImport("umf.DLL", EntryPoint = "fw_transfer")]
        public static extern Int32  fw_transfer(Int32 icdev,Byte _Adr);
        [DllImport("umf.DLL", EntryPoint = "fw_beep")]
        public static extern Int32  fw_beep(Int32 icdev,UInt32 _Msec);
        [DllImport("umf.DLL", EntryPoint = "fw_getver")]
        public static extern  Int32 fw_getver(Int32 icdev,ref Byte buff);
        [DllImport("umf.DLL", EntryPoint = "fw_reset")]
        public static extern Int16  fw_reset(Int32 icdev,UInt16 _Msec);
        [DllImport("umf.DLL",EntryPoint="hex_a")]
        public static extern void hex_a(ref Byte hex, ref Byte a,Int16 len);

        //Ultralight卡函数
        [DllImport("umf.dll",EntryPoint="fw_request_ultralt")]
        public static extern Int32 fw_request_ultralt(Int32 icdev, Byte _Mode);
        [DllImport("umf.dll",EntryPoint="fw_anticall_ultralt")]
        public static extern Int32 fw_anticall_ultralt(Int32 icdev, ref ulong _Snr);
        [DllImport("umf.dll", EntryPoint = "fw_select_ultralt")]
        public static extern Int32 fw_select_ultralt(Int32 icdev, ulong _Snr);
        [DllImport("umf.dll", EntryPoint = "fw_write_ultralt")]
        public static extern Int32 fw_write_ultralt(Int32 icdev, Byte iPage, ref Byte wdata);
        [DllImport("umf.dll", EntryPoint = "fw_read_ultralt")]
        public static extern Int32 fw_read_ultralt(Int32 icdev, Byte iPage, ref Byte rdata);



        Int32 ihdev;
        Int32[] devs;//保存多个设备句柄的数组
        Int32 state;
        bool isAuthen;
        bool isComOpen;
        Int32 curCardtype;

        Byte sector=6;//4;//M1 S70 卡操作的扇区号
        Byte Address = 24;//16;//第16块，注意：测试的时候不要写密码块
        //每个扇区的最后一个块是密码块，比如地址号为3、7、11等是密码块


        public Form1()
        {
            InitializeComponent();
            isComOpen = false;
            curCardtype = -1;
        }

        /// <summary>
        /// 打开串口
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
          

            Byte[] revbuf=new Byte[64];
            comboBox1.Items.Clear();

            if (!isComOpen)
            {
                /*得到当前连接的设备的句柄*/
                Int32 tmphdev = 0;
                if (radioButton1.Checked == true)
                {//USB方式
                    int i = 0;
                    do
                    {
                        tmphdev = fw_init(100, 0);
                        if (tmphdev > 0)
                        {
                            devs[i] = tmphdev;
                            string strdevs = "设备 ";
                            strdevs += i.ToString();
                            comboBox1.Items.Add(strdevs);
                            i++;
                        }

                    }
                    while (i < 100 && tmphdev > 0);

                    ihdev = devs[0];
                    comboBox1.SelectedIndex = 0;
                }
                else
                {//串口方式
                    Int16 fport = Int16.Parse(comboBox2.SelectedIndex.ToString());

                    ihdev = fw_init(fport, 115200);//波特率设为115200

                    if (ihdev > 0)
                    {
                        comboBox1.Items.Add("设备 0");
                        comboBox1.SelectedIndex = 0;
                    }

                }

                if (ihdev > 0)
                {
                    listBox1.Items.Add("打开设备成功！");
                    button1.Text = "关闭设备";
                    isComOpen = true;
                }
                else
                {
                    listBox1.Items.Add("打开设备失败！");
                    return;
                }

                state = fw_getver(ihdev, ref revbuf[0]);
                if (state != 0) listBox1.Items.Add("fw_getver Error");
                else
                {
                    listBox1.Items.Add("fw_getver OK");
                    ASCIIEncoding encod = new ASCIIEncoding();
                    listBox1.Items.Add(encod.GetString(revbuf));
                }
            }
            else
            {//关闭所有设备
                int i = 0;
                while (devs[i] > 0)
                {
                    fw_exit(devs[0]);
                    devs[i] = 0;
                    i++;
                }

                if (ihdev > 0)
                    fw_exit(ihdev);

                ihdev = 0;

                comboBox1.Items.Clear();
                button1.Text = "打开设备";

                isComOpen = false;
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ihdev = 0;
            devs = new Int32[100];
            for (int i = 0; i < 100; i++)
                devs[i] = 0;
            isAuthen=false;

            this.comboBox3.SelectedIndex = 0;
    

        }
        /// <寻卡>
        /// 寻卡
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {

            ulong cardnumber = new ulong();//卡号请定义成无符号的ulong型变量
                                           //否则，有可能得到带负号的整数

            switch (curCardtype)
            {
                case 0:                              //寻卡验证---M1卡
                case 1:                              //寻卡验证---S70卡
                    {
                        //fw_request 
                      /*  UInt32 cardtype = new UInt32();
                        Byte cardsize = new Byte();
                        state = fw_request(ihdev, 1, ref cardtype);
                        if (state != 0) listBox1.Items.Add("fw_request Error");
                        else listBox1.Items.Add("fw_request OK");

                        //fw_anticoll
                        state = fw_anticoll(ihdev, 0, ref cardnumber);
                        if (state != 0) listBox1.Items.Add("fw_anticoll Error");
                        else
                        {
                            listBox1.Items.Add("fw_anticoll OK");
                            listBox1.Items.Add(cardnumber);
                        }


                        //fw_select 
                        state = fw_select(ihdev, cardnumber, ref cardsize);
                        if (state != 0) listBox1.Items.Add("fw_select Error");
                        else listBox1.Items.Add("fw_select OK");*/


                        //fw_card
                        state = fw_card(ihdev, 1, ref cardnumber);//此函数相当于上面三步
                        if (state != 0) listBox1.Items.Add("fw_card Error");
                        else
                        {
                            listBox1.Items.Add("fw_card OK");
                        }

                        //fw_authentication
                        state = fw_authentication(ihdev, 0, sector );
                        if (state != 0) listBox1.Items.Add("fw_authentication Error");
                        else
                        {
                            listBox1.Items.Add("fw_authentication OK");
                            isAuthen = true;
                        }
                    }
                    break;
                case 2:
                    {
                        state = fw_request_ultralt(ihdev, 1);//1模式寻卡请求
                        state = fw_anticall_ultralt(ihdev, ref cardnumber);
                        state = fw_select_ultralt(ihdev, cardnumber);

                        if (state != 0)
                        {
                            listBox1.Items.Add("Find Card Error!");
                            return;
                        }
                        else
                        {
                            listBox1.Items.Add("Find Card Ok!");

                            listBox1.Items.Add(cardnumber);
                        }
                    }
                    break;
                default:
                    break;
            }





        }
        /// <装载密码>
        /// 装载密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            Byte[] key=new Byte[6];
            key[0]=0xff;
            key[1]=0xff;
            key[2]=0xff;
            key[3]=0xff;
            key[4]=0xff;
            key[5]=0xff;
            state = fw_load_key(ihdev, 0, 1,ref key[0]);
            if (state != 0)
            {
                listBox1.Items.Add("fw_load_key Error");
                return;
            }
            listBox1.Items.Add("fw_load_key OK");


        }
        /// <卡函数>
        /// 卡函数
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_Click(object sender, EventArgs e)
        {
            switch (curCardtype)
            {
                case 0:                               //卡函数（读写）----M1卡
                case 1:                               //卡函数（读写）----S70卡
                    {
                        if (!isAuthen)
                        {
                            MessageBox.Show("请先寻卡验证");
                            return;
                        }

                        Byte[] sendbuf ={ 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0x00, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF };
                        Byte[] revbuf = new Byte[16];
                        Byte[] showbuf = new Byte[255];

                        string w_data = "11223344556677889900AABBCCDDEEFF";
                        StringBuilder r_data = new StringBuilder (300000);



                        //fw_write
                       // state = fw_write(ihdev, Address, ref sendbuf[0]);
                        state = fw_write_hex(ihdev, Address, w_data);
                        if (state != 0) listBox1.Items.Add("fw_write Error");
                        else listBox1.Items.Add("fw_write OK");

                        
                        //fw_read
                       // state = fw_read(ihdev, Address, ref revbuf[0]);
                        
                        state = fw_read_hex(ihdev, Address,  r_data);
                        if (state != 0) listBox1.Items.Add("fw_read Error");
                        else
                        {
                           // listBox1.Items.Add("fw_read OK");
                           // hex_a(ref showbuf[0], ref revbuf[0], 32);
                           // ASCIIEncoding encoding = new ASCIIEncoding();
                           // listBox1.Items.Add(encoding.GetString(showbuf));

                            listBox1.Items.Add(r_data.ToString());
                        }

                        //写汉字示例
                        //string strW = "IC卡读写器";
                        //Byte[] wBytes =new byte [20];
                        //if (strW.Length!=0)
                        //   wBytes = System.Text.Encoding.Default.GetBytes(strW);
                        //else
                        //    wBytes[0]=0;

                        //state = fw_write(ihdev, Address, ref wBytes[0]);
                        //if (state != 0) listBox1.Items.Add("fw_write Error");
                        //else listBox1.Items.Add("fw_write OK");
                        //读汉字
                        //state = fw_read(ihdev, Address, ref revbuf[0]);
                        //if (state != 0) listBox1.Items.Add("fw_read Error");
                        //else
                        //{
                        //    listBox1.Items.Add("fw_read OK");
                        //    ASCIIEncoding encoding = new ASCIIEncoding();
                        //    listBox1.Items.Add(Encoding.Default.GetString(revbuf));
                        //}

                        //fw_halt
                        state = fw_halt(ihdev);
                        if (state != 0) listBox1.Items.Add("fw_halt Error");
                        else listBox1.Items.Add("fw_halt OK");

                        isAuthen = false;
                    }
                    break;
                case 2:
                    {
                        //读写卡操作之前，先读一下第0块
                        byte[] Data = new byte[6];
                        state = fw_read_ultralt(ihdev, 0, ref Data[0]);//读第0页
                        if (state != 0)
                        {
                            listBox1.Items.Add("Read Page0 Error!");
                            return;
                        }


                        //写卡
                        char[] chars={'M', 'M', 'M', 'M' };
                        byte[] newCardData = Encoding.Unicode.GetBytes(chars);

                        state = fw_write_ultralt(ihdev, 4, ref newCardData[0]);//写第4页

                        if (state != 0)
                        {
                            listBox1.Items.Add("fw_write_ultralt Error!");
                            return;
                        }

                        listBox1.Items.Add("fw_write_ultralt OK!");

                        //Read card

                        state = fw_read_ultralt(ihdev, 4, ref Data[0]);//读第4页的数据
                        if (state != 0)
                        {
                            listBox1.Items.Add("fw_read_ultralt Error!");
                            return;
                        }

                        listBox1.Items.Add("fw_read_ultralt Ok!");
                        listBox1.Items.Add(Data);
 
                    }
                    break;
                default:
                    break;
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //fw_reset
            state = fw_reset(ihdev, 10);
            if (state != 0) listBox1.Items.Add("fw_reset Error");
            else listBox1.Items.Add("fw_reset OK");

            //fw_beep
            state = fw_beep(ihdev, 10);
            if (state != 0)
            {
                listBox1.Items.Add("fw_beep Error");
                return;
            }
            listBox1.Items.Add("fw_beep OK");

        }
        /// <修改密码>
        /// 
        /// 修改密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button8_Click(object sender, EventArgs e)
        {
            if (!isAuthen)
            {
                MessageBox.Show("请先寻卡验证");
                return;
            }

            Byte[] keya ={ 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
            Byte[] ctrlbyte ={ 0xff, 0x7, 0x80, 0x69 };
            Byte[] keyb ={ 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

            //fw_change3
            state = fw_changeb3(ihdev, 1, ref keya[0], ref ctrlbyte[0],0, ref keyb[0]);
            if (state != 0) listBox1.Items.Add("fw_changeb3 Error");
            else listBox1.Items.Add("fw_changeb3 OK");

        }
        /// < 值操作>
        /// 值操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button7_Click(object sender, EventArgs e)
        {
            if (!isAuthen)
            {
                MessageBox.Show("请先寻卡验证");
                return;
            }


            uint value = 0;

            //fw_initval
            state = fw_initval(ihdev, Address, 1000);
            if (state != 0) listBox1.Items.Add("fw_initval Error");
            else listBox1.Items.Add("fw_initval OK");

            //fw_readval
            state = fw_readval(ihdev, Address, ref value);
            if (state != 0) listBox1.Items.Add("fw_readval Error");
            else
            {
                listBox1.Items.Add("fw_readval OK");
                listBox1.Items.Add(value);
            }

            //fw_increment 
            state = fw_increment(ihdev, Address, 10);
            if (state != 0) listBox1.Items.Add("fw_increment Error");
            else
            {
                state = fw_transfer(ihdev, Address);
                if (state != 0) listBox1.Items.Add("fw_increment Error");
                else listBox1.Items.Add("fw_increment OK");
            }


            //fw_decrement
            state = fw_decrement(ihdev, Address, 5);
            if (state != 0) listBox1.Items.Add("fw_decrement Error");
            else
            {
                state = fw_transfer(ihdev, Address);
                if (state != 0) listBox1.Items.Add("fw_transfer Error");
                else
                {
                    listBox1.Items.Add("fw_transfer OK");
                    listBox1.Items.Add("fw_decrement OK");
                }
            }

            //fw_restore
            state = fw_restore(ihdev, Address);
            if (state != 0) listBox1.Items.Add("fw_restore Error");
            else listBox1.Items.Add("fw_restore OK");

        }

        private void radioButton1_Click(object sender, EventArgs e)
        {
            comboBox2.Visible = false;
        }

        private void radioButton2_Click(object sender, EventArgs e)
        {
            comboBox2.Visible = true;
            comboBox2.SelectedIndex = 0;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        /// <summary>
        /// 选不同的卡型
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            curCardtype = comboBox3.SelectedIndex;

            if (2 == curCardtype)
            {
                setControlState(0);
            }
            else
                setControlState(1);
            
        }

        private void setControlState(int state)
        {
            if (state==1)
            {//如果是M1或S70的卡型

                this.button7.Enabled = true;
                this.button8.Enabled = true;
            }
            else
            {

                this.button7.Enabled = false;
                this.button8.Enabled = false;
            }
        }
        /// <summary>
        /// 选择当前要操作的设备
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBox1_Click(object sender, EventArgs e)
        {
            ihdev = devs[comboBox1.SelectedIndex];
        }

    }
}