<1>libS8.so,libS8.h��demo.c
<2>How to use.so: copy libS8.so to some director,/lib for example, then execute 'ldconfig' :
                     #cp libS8.so /lib/libS8.so
                     #ldconfig

                     Now,this so should be shared, to compile like command under:
                     #cc -o demo demo.c /lib/libS8.so

<3>Run the program: ./demo.o              
