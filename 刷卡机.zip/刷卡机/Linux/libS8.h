
#define  __int16    int

int read_serial(int fd,unsigned char* buff);
int write_serial(int fd,int data);
int fw_start_x(int icdev);
int fw_end_x(int icdev);
int fw_commInfo(int icdev,unsigned char slen,unsigned char* sdata,unsigned char *rlen,unsigned char* rdata);//
int fw_usbInfo(int icdev,unsigned char slen,unsigned char* sdata,unsigned char *rlen,unsigned char* rdata);//USB

int fw_init(int port,long baud);
int fw_exit(int fd);
__int16  a_hex(unsigned char *a,unsigned char *hex,__int16 len);
void  hex_a(unsigned char *hex,unsigned char *a,__int16 len);
int  fw_beep(int icdev,unsigned int _Msec);

int  fw_card(int icdev,unsigned char _Mode,unsigned long *_Snr);
int  fw_request(int icdev,unsigned char _Mode,unsigned int *TagType);
int  fw_anticoll(int icdev,unsigned char _Bcnt,unsigned long *_Snr);
int  fw_select(int icdev,unsigned long _Snr,unsigned char *_Size);
int  fw_load_key(int icdev,unsigned char _Mode,unsigned char _SecNr,unsigned char *_NKey);
int  fw_load_key_hex(int icdev,unsigned char _Mode,unsigned char _SecNr,unsigned char *_NKey);
int  fw_authentication(int icdev,unsigned char _Mode,unsigned char _SecNr);
int  fw_read(int icdev,unsigned char _Adr,unsigned char *_Data);
__int16  fw_read_hex(int icdev,unsigned char _Adr,char *_Data);
int  fw_write(int icdev,unsigned char _Adr,unsigned char *_Data);
__int16 fw_write_hex(int icdev,unsigned char _Adr,char *_Data);
int  fw_halt(int icdev);
int  fw_changeb3(int icdev,unsigned char _SecNr,unsigned char *_KeyA,unsigned char *_CtrlW,unsigned char _Bk,unsigned char *_KeyB);
int  fw_initval(int icdev,unsigned char _Adr,unsigned long _Value);
int fw_increment(int icdev,unsigned char _Adr,unsigned long _Value);
int  fw_readval(int icdev,unsigned char _Adr,unsigned long *_Value);
int  fw_decrement(int icdev,unsigned char _Adr,unsigned long _Value);
int  fw_restore(int icdev,unsigned char _Adr);
int  fw_transfer(int icdev,unsigned char _Adr);
__int16  fw_config_card(int icdev,unsigned char flags);

int  fw_getver(int icdev,unsigned char *buff);
int fw_srd_eeprom(int icdev,int offset,int length, unsigned char *rec_buffer);
int fw_swr_eeprom(int icdev,int offset,int length,unsigned char* buffer);
__int16 fw_reset(int icdev,unsigned __int16 _Msec);

